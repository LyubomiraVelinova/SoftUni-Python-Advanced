from project.darkwizard import DarkWizard


class SoulMaster(DarkWizard):
    pass