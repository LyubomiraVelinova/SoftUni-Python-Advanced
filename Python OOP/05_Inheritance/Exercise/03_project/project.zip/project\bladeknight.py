from project.darkknight import DarkKnight


class BladeKnight(DarkKnight):
    pass